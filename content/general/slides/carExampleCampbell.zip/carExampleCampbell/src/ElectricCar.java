import java.awt.*;

// This class demonstrates a VIOLATION of the Liskov Substitution Principle
// It violates it because attempting to refuel a car will fail
//  if the car is actually an ElectricCar!
public class ElectricCar extends Car {
    ElectricCar(Color color) {
        super(color);
    }

    @Override
    public void refuel(FuelCan fuelCan) {
        throw new RuntimeException("Electric Car can't be refueled!");
    }

    public void connectCharger() {
        /* ... */
    }
    public void disconnectCharger() {
        /* ... */
    }
}
