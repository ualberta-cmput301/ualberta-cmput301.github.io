public class Damage {

}
