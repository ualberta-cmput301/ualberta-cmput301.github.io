public class FuelCan {
    Double fuel;
    public Double drain() {
        Double drained = fuel;
        fuel = Double.valueOf(0.0);
        return drained;
    }
}
