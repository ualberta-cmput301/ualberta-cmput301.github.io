// This class demonstrates composition relationships:
//  * Engine 1----1
//  * Damages 1----0..*
//  * Paints 1----1..*
// This class demonstrates aggregation relationships:
//  * Tire 1----0..4
// This class demonstrates association relationships:
//  * ParkingLot 1----1
//  * FuelCan -----"drains"-----

import java.util.ArrayList;
import java.awt.Color;

public class Car implements Drivable {
    private ArrayList<Damage> damages;
    private ArrayList<Paint> paints;
    private final Tire[] tires = new Tire[4];
    private ParkingLot parkingLot;
    private Double fuel;

    public ParkingLot getParkingLot() {
        return parkingLot;
    }

    public void parkAt(ParkingLot parkingLot) {
        this.parkingLot = parkingLot;
    }

    public boolean isParked() {
        return this.parkingLot != null;
    }

    public void drive() {
        if (fuel > 1.0) {
            fuel -= 1.0;
        } else {
            throw new RuntimeException("Out of Gas!");
        }
    }

    private class Engine {
        // composition idea #1:
        // we can't even get an Engine out of the car
        // because it's a private inner class
    }

    private Engine engine;

    Car(Color color) {
        paints = new ArrayList<>();
        paints.add(new Paint(color, this));
    }

    public Engine getEngine() {
        return engine;
    }

    // composition idea #2:
    // we just simply never allow the damages out of the car...
    // we don't have any methods that return our windows!
    // we don't write anything public like this for composition
    private Damage getWindow(int index) {
       return damages.get(index);
    }

    public Paint getPaint(int index) {
        return paints.get(index);
    }

    // composition idea #3:
    // we mark the paints we were composed of as destroyed
    // paint is responsible for making sure it's useless after this
    public void destroy() {
        for (Paint paint : paints) {
            paint.destroy();
        }
    }
    public void addPaint(Paint paint) {
        paints.add(paint);
    }

    public Tire removeTire(int which) {
        Tire tire = tires[which];
        tires[which] = null;
        tire.setCar(null);
        return tire;
    }
    public void installTire(int which, Tire tire) {
        tires[which] = tire;
        tire.setCar(this);
    }

    public void refuel(FuelCan fuelCan) {
        fuel += fuelCan.drain();
    }
}
