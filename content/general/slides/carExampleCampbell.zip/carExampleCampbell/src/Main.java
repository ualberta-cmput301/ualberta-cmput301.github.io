import java.awt.*;
import java.util.ArrayList;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    int i = 33; // primitive type, it is actually not a reference
    Integer j = 33; // this is an instance of class Integer, it is a refernce
    private static void f(ArrayList<Integer> a) {
        a.set(3, 33);
        a = null;
    }

    public static void main(String[] args) {
        System.out.println("Hello and welcome!");
        ArrayList<Integer> a = new ArrayList<>();
        for (int i = 0; i <= 5; i++) {
            a.add(i);
            System.out.println("i = " + i + " a[i]= " + a.get(i));
        }
        f(a);
        for (int i = 0; i <= 5; i++) {
            System.out.println("i = " + i + " a[i]= " + a.get(i));
        }
    }

    Car car = new Car(
            new Color(0,0,0)
    );
    // Engine engine = car.getEngine(); // we can't do that!
}
