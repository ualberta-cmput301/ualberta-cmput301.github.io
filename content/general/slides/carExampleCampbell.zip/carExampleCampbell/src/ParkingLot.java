public class ParkingLot {
}
