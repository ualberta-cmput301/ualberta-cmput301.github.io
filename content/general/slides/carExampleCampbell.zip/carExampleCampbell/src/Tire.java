public class Tire {
    private Car car;
    public void setCar(Car car) {
        this.car = car;
    }
}
