import java.awt.Color;

public class Paint {
    private Car car;
    private Color color;

    Paint(Color color, Car car) {
        this.color = color;
        this.car = car;
    }
    public void destroy() {
            this.car = null;
    }
    private void validate() {
        if (car == null) {
            throw new RuntimeException("No paint without car!");
        }
    }
    public Color getColor() {
        validate();
        return color;
    }
}
